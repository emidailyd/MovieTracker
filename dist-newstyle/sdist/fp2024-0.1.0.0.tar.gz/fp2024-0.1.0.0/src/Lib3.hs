{-# OPTIONS_GHC -Wno-name-shadowing #-}
{-# OPTIONS_GHC -Wno-incomplete-patterns #-}
{-# LANGUAGE InstanceSigs #-}
module Lib3
    ( stateTransition,
    StorageOp (..),
    storageOpLoop,
    parseCommand,
    parseStatements,
    marshallState,
    renderStatements,
    Command(..),
    Statements(..),
    ) where

import Control.Concurrent (Chan, readChan, writeChan, newChan)
import Control.Concurrent.STM(TVar, atomically, writeTVar, readTVarIO, modifyTVar')
import System.IO (withFile, IOMode(..), hPutStr)
import qualified Data.List as L

import qualified Lib2

data StorageOp = Save String (Chan ()) | Load (Chan String)
-- | This function is started from main
-- in a dedicated thread. It must be used to control
-- file access in a synchronized manner: read requests
-- from chan, do the IO operations needed and respond
-- to a channel provided in a request.
-- Modify as needed.
storageOpLoop :: Chan StorageOp -> IO ()
storageOpLoop chan = do
  op <- readChan chan
  case op of

    Save content notifyChan -> do
      withFile "state.txt" WriteMode $ \handle -> hPutStr handle content
      writeChan notifyChan ()
    
    Load responseChan -> do
      content <- fmap (filter (/= '\r')) (readFile "state.txt")
      writeChan responseChan content
  
  storageOpLoop chan


data Statements = Batch [Lib2.Query] |
               Single Lib2.Query
               deriving (Show, Eq)

data Command = StatementCommand Statements |
               LoadCommand |
               SaveCommand
               deriving (Show, Eq)

-- Statements, Load, or Save.
parseCommand :: String -> Either String (Command, String)
parseCommand input
  | L.isPrefixOf "load" input = Right (LoadCommand, drop (length "load") input)
  | L.isPrefixOf "save" input = Right (SaveCommand, drop (length "save") input)
  | L.isPrefixOf "BEGIN" input = parseBeginBlock input
  | otherwise = do
      (statements, rest) <- parseStatements input
      return (StatementCommand statements, rest)

parseBeginBlock :: String -> Either String (Command, String)
parseBeginBlock input = do
  let linesInput = map Lib2.trim (lines input)
  if not ("BEGIN" `elem` linesInput) || not ("END" `elem` linesInput)
    then Left "Error: BEGIN-END block is incomplete"
    else do
      let blockLines = takeWhile (/= "END") $ drop 1 $ dropWhile (/= "BEGIN") linesInput
      if null blockLines
        then Left "Error: BEGIN-END block contains no statements"
        else do
          queries <- mapM Lib2.parseQuery blockLines
          return (StatementCommand (Batch queries), "")



-- | Parses Statement.
-- Must be used in parseCommand.
-- Reuse Lib2 as much as you can.
-- You can change Lib2.parseQuery signature if needed.
parseStatements :: String -> Either String (Statements, String)
parseStatements input
  | L.isPrefixOf "BEGIN" input = do
      (command, rest) <- parseBeginBlock input
      case command of
        StatementCommand statements -> return (statements, rest)
        _ -> Left "Error: BEGIN block did not produce a valid StatementCommand"
  | otherwise = do
      query <- Lib2.parseQuery input
      return (Single query, "")




-- | Converts program's state into Statements
-- (probably a batch, but might be a single query)
-- | Converts program's state into Statements (probably a batch of queries)
marshallState :: Lib2.State -> Statements
marshallState state =
  let queries = generateQueries (Lib2.movies state)
  in Batch queries

-- Generate a list of queries for saving the state
generateQueries :: [Lib2.Movie] -> [Lib2.Query]
generateQueries movies =
  let sortedMovies = L.sortBy (\a b -> compare (Lib2.movieId a) (Lib2.movieId b)) movies
  in concatMap generateMovieCommands sortedMovies

-- Generate both add_movie and optional rate_movie commands for a single movie
generateMovieCommands :: Lib2.Movie -> [Lib2.Query]
generateMovieCommands (Lib2.Movie movieId title genre director year rating) =
  let addCommand = Lib2.AddMovie title genre director year
      rateCommand = if rating /= 0.0
                    then [Lib2.RateMovie movieId rating]
                    else []
  in [addCommand] ++ rateCommand


-- | Renders Statements into a String which
-- can be parsed back into Statements by parseStatements
-- function. The String returned by this function must be used
-- as persist program's state in a file. 
-- Must have a property test
-- for all s: parseStatements (renderStatements s) == Right(s, "")
renderStatements :: Statements -> String
renderStatements (Single query) = renderQuery query
renderStatements (Batch queries) =
  "BEGIN\n" ++ unlines (map renderQuery queries) ++ "END\n"

-- render a single query to a string
renderQuery :: Lib2.Query -> String
renderQuery (Lib2.AddMovie title genre director year) =
  "add_movie(" ++ title ++ ", " ++ genre ++ ", " ++ director ++ ", " ++ show year ++ ")"
renderQuery (Lib2.RateMovie movieId rating) =
  "rate_movie(" ++ show movieId ++ ", " ++ show rating ++ ")"


convertCommandToLib2Query :: Command -> Either String (Maybe Lib2.Query, Maybe StorageOp)
convertCommandToLib2Query (StatementCommand (Batch queries)) =
    Right (Just (Lib2.Sequence queries), Nothing)

convertCommandToLib2Query (StatementCommand (Single (Lib2.AddMovie title genre director year))) =
    Right (Just (Lib2.AddMovie title genre director year), Nothing)

convertCommandToLib2Query (StatementCommand (Single (Lib2.RemoveMovie movieId))) =
    Right (Just (Lib2.RemoveMovie movieId), Nothing)

convertCommandToLib2Query (StatementCommand (Single (Lib2.ViewMovieDetails movieId))) =
    Right (Just (Lib2.ViewMovieDetails movieId), Nothing)

convertCommandToLib2Query (StatementCommand (Single (Lib2.RateMovie movieId rating))) =
    Right (Just (Lib2.RateMovie movieId rating), Nothing)

convertCommandToLib2Query (StatementCommand (Single (Lib2.UpdateMovie movieId title genre director year))) =
    Right (Just (Lib2.UpdateMovie movieId title genre director year), Nothing)

convertCommandToLib2Query (StatementCommand (Single (Lib2.ListMovies filter))) =
    Right (Just (Lib2.ListMovies filter), Nothing)

convertCommandToLib2Query SaveCommand = Right (Nothing, Just (Save "state.txt" undefined))
convertCommandToLib2Query LoadCommand = Right (Nothing, Just (Load undefined))

convertCommandToLib2Query _ = 
    Left "Unsupported command"



-- | Updates a state according to a command.
-- Performs file IO via ioChan if needed.
-- This allows your program to share the state
-- between repl iterations, save the state to a file,
-- load the state from the file so the state is preserved
-- between program restarts.
-- Keep IO as small as possible.
-- State update must be executed atomically (STM).
-- Right contains an optional message to print, updated state
-- is stored in transactinal variable
-- | Updates the state according to a command, handling file I/O if necessary.
-- The function performs all state transitions atomically, and communicates with the storage thread via ioChan for file operations.
stateTransition :: TVar Lib2.State -> Command -> Chan StorageOp -> IO (Either String (Maybe String, Lib2.State))
stateTransition stateVar command ioChan = do
    -- Read the current state first
    currentState <- readTVarIO stateVar
    (result, maybeStorageOp) <- atomically $ do
        let conversionResult = convertCommandToLib2Query command
        case conversionResult of
            Left err -> return (Left err, Nothing)
            Right (Nothing, Just storageOp) -> 
                return (Right (Nothing, currentState), Just storageOp)
            Right (Just query, Nothing) -> do
                let (msg, newState) = case Lib2.stateTransition currentState query of
                        Right (msg, newState) -> (msg, newState)
                        Left _ -> (Nothing, currentState)
                writeTVar stateVar newState
                return (Right (msg, newState), Nothing)

    case command of
        LoadCommand -> do
            -- Dynamically create a response channel
            responseChan <- newChan
            let loadOp = Load responseChan
            -- Execute the StorageOp
            writeChan ioChan loadOp
            -- Wait for the file content to be loaded
            loadedContent <- readChan responseChan
            case parseBeginBlock loadedContent of
                Left parseError -> return (Left parseError)
                Right (StatementCommand (Batch queries), _) -> do
                    -- Apply the parsed queries to the state
                    atomically $ modifyTVar' stateVar (\currentState ->
                        foldl applyQuery currentState queries)
                    updatedState <- readTVarIO stateVar
                    return (Right (Just "State loaded successfully.", updatedState))
                Right _ -> return (Left "Invalid BEGIN-END block structure.")


        SaveCommand -> do
            let statements = marshallState currentState
            let renderedStatements = renderStatements statements
            notifyChan <- newChan
            writeChan ioChan (Save renderedStatements notifyChan)
            return (Right (Just "State saved successfully.", currentState))
        _ -> case maybeStorageOp of
            Just storageOp -> do
                writeChan ioChan storageOp
                return result
            Nothing -> return result
  where
    -- Helper to apply a query to the state
    applyQuery state query =
        case Lib2.stateTransition state query of
            Right (_, newState) -> newState
            Left _ -> state
