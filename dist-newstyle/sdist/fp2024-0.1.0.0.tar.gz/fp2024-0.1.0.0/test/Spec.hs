{-# OPTIONS_GHC -Wno-name-shadowing #-}
{-# OPTIONS_GHC -Wno-incomplete-patterns #-}
{-# LANGUAGE InstanceSigs #-}

module Lib3Test where

import Test.QuickCheck
import Lib3
import qualified Lib2
import Control.Monad (replicateM)
import qualified Data.List as L

-- List of available genres
availableGenres :: [String]
availableGenres = ["Action", "Comedy", "Drama", "Horror", "SciFi", "Romance"]

-- Arbitrary instance for Movie, ensuring genre is one of the available ones and rating is between 0.0 and 9.9 with one decimal place
instance Arbitrary Lib2.Movie where
    arbitrary = do
        movieId <- arbitrary
        title <- arbitrary
        genre <- elements availableGenres
        director <- arbitrary
        year <- arbitrary
        rating <- choose (0.0, 9.9) -- Random rating between 0.0 and 9.9
        let ratingWithOneDecimal = fromIntegral (round (rating * 10) :: Int) / 10 -- Ensure rating has one decimal place
        return (Lib2.Movie movieId title genre director year ratingWithOneDecimal)

-- Arbitrary instance for Query, allowing random AddMovie or RateMovie queries
instance Arbitrary Lib2.Query where
    arbitrary = do
        title <- arbitrary
        genre <- elements availableGenres
        director <- arbitrary
        year <- arbitrary
        rating <- choose (0.0, 9.9)
        let ratingWithOneDecimal = fromIntegral (round (rating * 10) :: Int) / 10
        -- Randomly choose between AddMovie or RateMovie
        oneof [ return (Lib2.AddMovie title genre director year)
              , return (Lib2.RateMovie movieId ratingWithOneDecimal)
              ]

-- Arbitrary instance for Statements
instance Arbitrary Lib3.Statements where
    arbitrary = do
        -- Generate either a single statement or a batch of statements
        frequency [ (1, Lib3.Single <$> arbitrary)
                  , (3, Lib3.Batch <$> arbitrary)
                  ]

-- The property test for marshallState and renderStatements
prop_marshallRender :: Lib2.State -> Property
prop_marshallRender state = 
    let statements = Lib3.marshallState state
        rendered = Lib3.renderStatements statements
        parsed = Lib3.parseStatements rendered
    in case parsed of
        Right (parsedStatements, "") -> parsedStatements == statements
        _ -> False

-- Test for marshallState and renderStatements
main :: IO ()
main = do
    quickCheck prop_marshallRender
